package com.example.one

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.time.LocalDate
import java.time.Period

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val spinnerDay: Spinner = findViewById(R.id.spinner_day)
        val spinnerMonth: Spinner = findViewById(R.id.spinner_month)
        val spinnerYear: Spinner = findViewById(R.id.spinner_year)
        val btnCalculate: Button = findViewById(R.id.btn_calculate)
        val tvResult: TextView = findViewById(R.id.tv_result)
        val tvDetails: TextView = findViewById(R.id.tv_details)

        // Poblar Spinner con días (1-31)
        val days = (1..31).map { it.toString() }
        val dayAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, days)
        dayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerDay.adapter = dayAdapter

        // Poblar Spinner con meses (1-12)
        val months = (1..12).map { it.toString() }
        val monthAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, months)
        monthAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerMonth.adapter = monthAdapter

        // Poblar Spinner con años (1900 hasta el año actual)
        val currentYear = LocalDate.now().year
        val years = (1900..currentYear).map { it.toString() }
        val yearAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, years)
        yearAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerYear.adapter = yearAdapter

        btnCalculate.setOnClickListener {
            val day = spinnerDay.selectedItem.toString().toIntOrNull()
            val month = spinnerMonth.selectedItem.toString().toIntOrNull()
            val year = spinnerYear.selectedItem.toString().toIntOrNull()

            if (day != null && month != null && year != null) {
                try {
                    val birthDate = LocalDate.of(year, month, day)
                    val currentDate = LocalDate.now()
                    val period = Period.between(birthDate, currentDate)

                    val years = period.years
                    val months = period.months
                    val days = period.days

                    tvResult.text = "Han passat:"
                    tvDetails.text = "$years anys, $months mesos, $days dies"
                    tvResult.visibility = TextView.VISIBLE
                    tvDetails.visibility = TextView.VISIBLE
                } catch (e: Exception) {
                    tvResult.text = "Error: Data invàlida"
                    tvDetails.text = ""
                    tvResult.visibility = TextView.VISIBLE
                    tvDetails.visibility = TextView.GONE
                }
            } else {
                tvResult.text = "Error: Entrada invàlida"
                tvDetails.text = ""
                tvResult.visibility = TextView.VISIBLE
                tvDetails.visibility = TextView.GONE
            }
        }
    }
}
